//
// COMP-GENG 422 - Tom Lupfer
//
// Compact embedded printf() module header file
//

#ifndef EPRINTF_H_
#define EPRINTF_H_

int eprintf(char * FmtStrPtr, ...);

#endif	// EPRINTF_H_
