//
// COMP-GENG 422 - Tom Lupfer
//
// UART module header file
//

#ifndef UART_H_
#define UART_H_

void UartInit(void);
int UartCharWrite(int OutChar);

#endif // UART_H_
