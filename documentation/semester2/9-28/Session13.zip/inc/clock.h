//
// COMP-GENG 422 - Tom Lupfer
//
// Clock system configuration module header file
//

#ifndef CLOCK_H_
#define CLOCK_H_

void ClockConfig(void);

#endif // CLOCK_H_
