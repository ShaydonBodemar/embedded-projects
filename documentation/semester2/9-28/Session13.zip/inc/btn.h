//
// COMP-GENG 422 - Tom Lupfer
//
// User pushbutton module header file
//

#ifndef BTN_H_
#define BTN_H_

#define BTN_TASK_PRI			1
#define BTN_TASK_STACK			500


void BtnPressTask(void *pvParameters);

#endif // BTN_H_
