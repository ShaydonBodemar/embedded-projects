//
// COMP-GENG 422 - Tom Lupfer
//
// Output module header file
//

#ifndef OUT_H_
#define OUT_H_

#define OUT_TASK_PRI			1
#define OUT_TASK_STACK			1000


void OutTask(void *pvParameters);

#endif // OUT_H_
